# PreciousX Render/Railway Deploy

This package is flattened for direct deployment on Render or Railway.

## Files
- `index.js` — Express server entrypoint
- `package.json` — dependencies + `npm start`
- `index.html`, JS, CSS, images — built frontend files at the root
- `render.yaml` — optional Render config

## Run locally
```bash
npm install
npm start
```

The server listens on `process.env.PORT`.

## Routes
- `/` — serves the app
- `/health` — health check
- `/api/hello` — returns `{ "message": "Hello World" }`

## Deploy to Render
1. Replace your GitHub repo root with these files.
2. Create a **Web Service** in Render connected to that repo.
3. Build Command: `npm install`
4. Start Command: `npm start`

## Deploy to Railway
1. Replace your GitHub repo root with these files.
2. Deploy the repo in Railway.
3. Railway will detect Node automatically and run `npm start`.
