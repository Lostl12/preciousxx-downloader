const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;

app.disable("x-powered-by");

app.get("/health", (_req, res) => {
  res.status(200).send("OK");
});

app.get("/api/hello", (_req, res) => {
  res.status(200).json({ message: "Hello World" });
});

app.use(express.static(ROOT));

app.get("*", (_req, res) => {
  res.sendFile(path.join(ROOT, "index.html"));
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
