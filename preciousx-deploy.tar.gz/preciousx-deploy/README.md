# PRECIOUS x Downloader

Universal video downloader — YouTube, TikTok, Instagram, Twitter & more.

## Deploy on Render

1. Push this folder to a GitHub repo
2. Go to [render.com](https://render.com) → New → Web Service
3. Connect your repo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** Node
5. Deploy!

## Deploy on Railway

1. Push this folder to a GitHub repo
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Select your repo — Railway auto-detects Node.js
4. It will run `npm install` then `npm start` automatically
5. Done!

## Local Testing

```bash
npm install
npm start
# Open http://localhost:3000
```

## Structure

```
index.js       ← Express server (entry point)
package.json   ← Dependencies & start script
dist/          ← Pre-built React frontend
```
