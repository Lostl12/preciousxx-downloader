const express = require("express");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// Serve static files from the built React app
app.use(express.static(path.join(__dirname, "dist")));

// SPA fallback — all routes serve index.html so React Router works
app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "dist", "index.html"));
});

app.listen(PORT, () => {
  console.log(`🚀 PRECIOUS x server running on port ${PORT}`);
});
