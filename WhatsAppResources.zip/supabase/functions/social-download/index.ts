const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const HEADERS = {
  ...corsHeaders,
  "Content-Type": "application/json",
};

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

interface Quality { label: string; url: string; }
interface DownloadResult { thumbnail: string; title: string; qualities: Quality[]; }

function detectPlatform(url: string): string {
  if (url.includes("youtube.com") || url.includes("youtu.be")) return "youtube";
  if (url.includes("tiktok.com")) return "tiktok";
  if (url.includes("instagram.com")) return "instagram";
  if (url.includes("twitter.com") || url.includes("x.com")) return "twitter";
  if (url.includes("facebook.com") || url.includes("fb.watch")) return "facebook";
  if (url.includes("pinterest.com") || url.includes("pin.it")) return "pinterest";
  if (url.includes("reddit.com") || url.includes("redd.it")) return "reddit";
  if (url.includes("vimeo.com")) return "vimeo";
  return "generic";
}

async function tryReq<T>(fn: () => Promise<T>, attempts = 3): Promise<T> {
  let err: Error | undefined;
  for (let i = 1; i <= attempts; i++) {
    try { return await fn(); } catch (e) {
      err = e instanceof Error ? e : new Error(String(e));
      if (i < attempts) await new Promise(r => setTimeout(r, 1000 * i));
    }
  }
  throw err;
}

function getYTId(url: string): string {
  return url.match(/(?:v=|youtu\.be\/|shorts\/)([a-zA-Z0-9_-]{11})/)?.[1] || "";
}

// ============ YouTube: EliteProTech (from api.js - PRIMARY) ============
async function youtubeEliteProTech(url: string): Promise<DownloadResult> {
  const qualities: Quality[] = [];
  const ytId = getYTId(url);

  const [mp4Res, mp3Res] = await Promise.allSettled([
    tryReq(() => fetch(`https://eliteprotech-apis.zone.id/ytdown?url=${encodeURIComponent(url)}&format=mp4`, {
      headers: { "User-Agent": UA, Accept: "application/json" }
    })),
    tryReq(() => fetch(`https://eliteprotech-apis.zone.id/ytdown?url=${encodeURIComponent(url)}&format=mp3`, {
      headers: { "User-Agent": UA, Accept: "application/json" }
    })),
  ]);

  let title = "YouTube Media";
  if (mp4Res.status === "fulfilled") {
    const d = await mp4Res.value.json();
    if (d.success && d.downloadURL) {
      qualities.push({ label: "MP4 Video", url: d.downloadURL });
      title = d.title || title;
    }
  }
  if (mp3Res.status === "fulfilled") {
    const d = await mp3Res.value.json();
    if (d.success && d.downloadURL) qualities.push({ label: "MP3 Audio", url: d.downloadURL });
  }

  if (qualities.length === 0) throw new Error("EliteProTech failed");
  return { thumbnail: ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : "", title, qualities };
}

// ============ YouTube: Yupra (from api.js - FALLBACK 1) ============
async function youtubeYupra(url: string): Promise<DownloadResult> {
  const qualities: Quality[] = [];
  const ytId = getYTId(url);
  let title = "YouTube Media";
  let thumbnail = ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : "";

  const [mp4Res, mp3Res] = await Promise.allSettled([
    tryReq(() => fetch(`https://api.yupra.my.id/api/downloader/ytmp4?url=${encodeURIComponent(url)}`, { headers: { "User-Agent": UA } })),
    tryReq(() => fetch(`https://api.yupra.my.id/api/downloader/ytmp3?url=${encodeURIComponent(url)}`, { headers: { "User-Agent": UA } })),
  ]);

  if (mp4Res.status === "fulfilled") {
    const d = await mp4Res.value.json();
    if (d.success && d.data?.download_url) {
      qualities.push({ label: "MP4 Video", url: d.data.download_url });
      title = d.data.title || title;
      thumbnail = d.data.thumbnail || thumbnail;
    }
  }
  if (mp3Res.status === "fulfilled") {
    const d = await mp3Res.value.json();
    if (d.success && d.data?.download_url) qualities.push({ label: "MP3 Audio", url: d.data.download_url });
  }

  if (qualities.length === 0) throw new Error("Yupra failed");
  return { thumbnail, title, qualities };
}

// ============ YouTube: Izumi (from api.js - FALLBACK 2) ============
async function youtubeIzumi(url: string): Promise<DownloadResult> {
  const ytId = getYTId(url);
  const res = await tryReq(() => fetch(`https://izumiiiiiiii.dpdns.org/downloader/youtube?url=${encodeURIComponent(url)}&format=mp3`, {
    headers: { "User-Agent": UA }
  }));
  const d = await res.json();
  if (!d.result?.download) throw new Error("Izumi failed");
  return {
    thumbnail: d.result.thumbnail || (ytId ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg` : ""),
    title: d.result.title || "YouTube Media",
    qualities: [{ label: "MP3 Audio", url: d.result.download }],
  };
}

// ============ TikTok: tikwm (from api.js) ============
async function tiktokDownload(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://tikwm.com/api/?url=${encodeURIComponent(url)}`, {
    headers: { "User-Agent": UA, Accept: "*/*" },
  });
  const d = await res.json();
  if (!d.data?.play) throw new Error("TikTok failed");
  const qualities: Quality[] = [{ label: "HD Video (No Watermark)", url: d.data.play }];
  if (d.data.wmplay) qualities.push({ label: "Watermark Video", url: d.data.wmplay });
  if (d.data.music) qualities.push({ label: "Audio MP3", url: d.data.music });
  return { thumbnail: d.data.cover || "", title: d.data.title || "TikTok Video", qualities };
}

// ============ Instagram: siputzx (PRIMARY) ============
async function instagramSiputzx(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(url)}`, {
    headers: { "User-Agent": UA },
  });
  const d = await res.json();
  const qualities: Quality[] = [];
  let thumbnail = "";

  if (d.data && Array.isArray(d.data)) {
    d.data.forEach((item: { url?: string; type?: string; thumbnail?: string }, i: number) => {
      if (item.url) qualities.push({ label: item.type || `Download ${i + 1}`, url: item.url });
      if (item.thumbnail && !thumbnail) thumbnail = item.thumbnail;
    });
  }
  if (qualities.length === 0) throw new Error("No Instagram links");
  return { thumbnail, title: "Instagram Media", qualities };
}

// ============ Instagram: GiftedTech (FALLBACK) ============
async function instagramGifted(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://api.giftedtech.co.ke/api/download/instagram?apikey=gifted&url=${encodeURIComponent(url)}`, {
    headers: { "User-Agent": UA },
  });
  const d = await res.json();
  if (!d.success) throw new Error("Instagram GiftedTech failed");
  const qualities: Quality[] = [];
  let thumbnail = "";
  if (Array.isArray(d.result)) {
    d.result.forEach((item: { url?: string; type?: string; thumbnail?: string }, i: number) => {
      if (item.url) qualities.push({ label: item.type || `Download ${i + 1}`, url: item.url });
      if (item.thumbnail && !thumbnail) thumbnail = item.thumbnail;
    });
  } else if (d.result?.download_url) {
    qualities.push({ label: "HD", url: d.result.download_url });
    thumbnail = d.result.thumbnail || "";
  }
  if (qualities.length === 0) throw new Error("No Instagram links from GiftedTech");
  return { thumbnail, title: "Instagram Media", qualities };
}

// ============ Pinterest: Server-side HTML scraping ============
async function pinterestDownload(url: string): Promise<DownloadResult> {
  // Follow redirects for pin.it short URLs
  const res = await fetch(url, {
    headers: { "User-Agent": UA, Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8" },
    redirect: "follow",
  });
  if (!res.ok) throw new Error(`Pinterest fetch ${res.status}`);
  const html = await res.text();

  const qualities: Quality[] = [];
  let thumbnail = "";
  let title = "Pinterest Pin";

  // Extract og:image
  const ogMatch = html.match(/<meta[^>]+(?:property|name)="og:image"[^>]+content="([^"]+)"/i)
    || html.match(/<meta[^>]+content="([^"]+)"[^>]+(?:property|name)="og:image"/i);
  const ogImage = ogMatch?.[1] || "";

  // Extract og:title
  const titleMatch = html.match(/<meta[^>]+(?:property|name)="og:title"[^>]+content="([^"]+)"/i)
    || html.match(/<meta[^>]+content="([^"]+)"[^>]+(?:property|name)="og:title"/i);
  title = titleMatch?.[1] || "Pinterest Pin";

  if (ogImage) {
    thumbnail = ogImage;
    // Get original/highest quality by replacing dimension segment
    const originalUrl = ogImage.replace(/\/\d+x\d*\//, "/originals/");
    qualities.push({ label: "HD Original Image", url: originalUrl });
    if (originalUrl !== ogImage) qualities.push({ label: "Standard Image", url: ogImage });
  }

  // Check for video pins
  const videoPatterns = [
    /"video_list":\s*\{[^}]*"V_720P":\s*\{[^}]*"url":\s*"([^"]+)"/,
    /"url":\s*"(https:\/\/v1?\.pinimg\.com\/videos\/[^"]+)"/,
    /"video_url":\s*"([^"]+)"/,
  ];
  for (const pattern of videoPatterns) {
    const m = html.match(pattern);
    if (m?.[1]) {
      const videoUrl = m[1].replace(/\\u002F/g, "/").replace(/\\\//g, "/");
      if (videoUrl.includes("pinimg.com")) {
        qualities.unshift({ label: "HD Video", url: videoUrl });
        break;
      }
    }
  }

  // Try JSON-LD
  const jsonLdMatch = html.match(/<script[^>]*type="application\/ld\+json"[^>]*>([\s\S]*?)<\/script>/i);
  if (jsonLdMatch?.[1]) {
    try {
      const ld = JSON.parse(jsonLdMatch[1]);
      if (ld.video?.contentUrl) qualities.unshift({ label: "HD Video", url: ld.video.contentUrl });
      if (ld.image && !thumbnail) {
        const imgUrl = typeof ld.image === "string" ? ld.image : ld.image?.url;
        if (imgUrl) { thumbnail = imgUrl; qualities.push({ label: "Image", url: imgUrl }); }
      }
    } catch { /* ignore */ }
  }

  if (qualities.length === 0) throw new Error("Could not extract Pinterest media");

  // Deduplicate
  const seen = new Set<string>();
  const unique = qualities.filter(q => { if (seen.has(q.url)) return false; seen.add(q.url); return true; });

  return { thumbnail, title, qualities: unique };
}

// ============ Twitter: GiftedTech fallback ============
async function twitterDownload(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://api.giftedtech.co.ke/api/download/twitter?apikey=gifted&url=${encodeURIComponent(url)}`, {
    headers: { "User-Agent": UA },
  });
  const d = await res.json();
  if (!d.success) throw new Error("Twitter download failed");
  const qualities: Quality[] = [];
  if (Array.isArray(d.result)) {
    d.result.forEach((item: { url?: string; quality?: string }, i: number) => {
      if (item.url) qualities.push({ label: item.quality || `Quality ${i + 1}`, url: item.url });
    });
  } else if (d.result?.download_url) {
    qualities.push({ label: "HD Video", url: d.result.download_url });
  }
  if (qualities.length === 0) throw new Error("No Twitter links");
  return { thumbnail: d.result?.thumbnail || "", title: "Twitter/X Media", qualities };
}

// ============ Facebook: GiftedTech fallback ============
async function facebookDownload(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://api.giftedtech.co.ke/api/download/facebook?apikey=gifted&url=${encodeURIComponent(url)}`, {
    headers: { "User-Agent": UA },
  });
  const d = await res.json();
  if (!d.success) throw new Error("Facebook download failed");
  const qualities: Quality[] = [];
  if (d.result?.hd) qualities.push({ label: "HD Video", url: d.result.hd });
  if (d.result?.sd) qualities.push({ label: "SD Video", url: d.result.sd });
  if (d.result?.download_url) qualities.push({ label: "Download", url: d.result.download_url });
  if (qualities.length === 0) throw new Error("No Facebook links");
  return { thumbnail: d.result?.thumbnail || "", title: "Facebook Video", qualities };
}

// ============ Reddit: GiftedTech fallback ============
async function redditDownload(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://api.giftedtech.co.ke/api/download/reddit?apikey=gifted&url=${encodeURIComponent(url)}`, {
    headers: { "User-Agent": UA },
  });
  const d = await res.json();
  if (!d.success) throw new Error("Reddit download failed");
  const qualities: Quality[] = [];
  const r = d.result;
  if (r) {
    if (r.hd) qualities.push({ label: "HD Video", url: r.hd });
    if (r.sd) qualities.push({ label: "SD Video", url: r.sd });
    if (r.download_url) qualities.push({ label: "Download", url: r.download_url });
    if (r.audio) qualities.push({ label: "Audio", url: r.audio });
  }
  if (qualities.length === 0) throw new Error("No Reddit links");
  return { thumbnail: r?.thumbnail || "", title: r?.title || "Reddit Media", qualities };
}

// ============ MAIN HANDLER ============
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  try {
    const { url } = await req.json();
    if (!url || typeof url !== "string") {
      return new Response(JSON.stringify({ error: "URL is required" }), { status: 400, headers: HEADERS });
    }

    const platform = detectPlatform(url);
    const errors: string[] = [];
    let result: DownloadResult | null = null;

    // Platform-specific handler chains
    const handlers: Record<string, Array<{ name: string; fn: (u: string) => Promise<DownloadResult> }>> = {
      youtube: [
        { name: "EliteProTech", fn: youtubeEliteProTech },
        { name: "Yupra", fn: youtubeYupra },
        { name: "Izumi", fn: youtubeIzumi },
      ],
      tiktok: [{ name: "TikWM", fn: tiktokDownload }],
      instagram: [{ name: "Siputzx", fn: instagramSiputzx }, { name: "GiftedTech-IG", fn: instagramGifted }],
      pinterest: [{ name: "Pinterest-Scrape", fn: pinterestDownload }],
      twitter: [{ name: "Twitter", fn: twitterDownload }],
      facebook: [{ name: "Facebook", fn: facebookDownload }],
      reddit: [{ name: "Reddit", fn: redditDownload }],
    };

    const chain = handlers[platform] || [];
    for (const h of chain) {
      try { result = await h.fn(url); break; } catch (e) {
        errors.push(`${h.name}: ${e instanceof Error ? e.message : "failed"}`);
      }
    }

    // Generic fallback: try all non-attempted handlers
    if (!result) {
      const allHandlers = [
        { name: "Pinterest", fn: pinterestDownload },
        { name: "TikTok", fn: tiktokDownload },
        { name: "Instagram", fn: instagramGifted },
        { name: "Twitter", fn: twitterDownload },
        { name: "Facebook", fn: facebookDownload },
      ];
      for (const h of allHandlers) {
        if (errors.some(e => e.startsWith(h.name))) continue;
        try { result = await h.fn(url); break; } catch { continue; }
      }
    }

    if (!result) {
      console.error("All handlers failed:", errors);
      return new Response(
        JSON.stringify({ error: "Could not fetch media from this URL. Try a different link." }),
        { status: 422, headers: HEADERS }
      );
    }

    return new Response(JSON.stringify(result), { status: 200, headers: HEADERS });
  } catch (err) {
    console.error("Edge function error:", err);
    return new Response(JSON.stringify({ error: "Internal server error" }), { status: 500, headers: HEADERS });
  }
});
