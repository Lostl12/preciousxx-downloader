import { Youtube, Instagram, Music, Twitter, Facebook, Image, Film, Video } from "lucide-react";

export interface Platform {
  id: string;
  name: string;
  icon: typeof Youtube;
  color: string;
  gradient: string;
  description: string;
  placeholder: string;
  supportedFormats: string[];
}

export const platforms: Platform[] = [
  {
    id: "youtube",
    name: "YouTube",
    icon: Youtube,
    color: "text-red-500",
    gradient: "from-red-600 to-red-400",
    description: "Download videos, shorts & music from YouTube with the working quality options available",
    placeholder: "https://youtube.com/watch?v=...",
    supportedFormats: ["MP4 720p", "MP4 480p", "MP3 128kbps"],
  },
  {
    id: "tiktok",
    name: "TikTok",
    icon: Music,
    color: "text-pink-400",
    gradient: "from-pink-500 to-cyan-400",
    description: "Download TikTok videos without watermark + audio",
    placeholder: "https://tiktok.com/@user/video/...",
    supportedFormats: ["HD Video", "Watermark Video", "MP3 Audio"],
  },
  {
    id: "instagram",
    name: "Instagram",
    icon: Instagram,
    color: "text-fuchsia-500",
    gradient: "from-fuchsia-600 to-orange-400",
    description: "Download Reels, Stories, Posts & IGTV from Instagram",
    placeholder: "https://instagram.com/p/...",
    supportedFormats: ["HD Video", "SD Video", "Photo"],
  },
  {
    id: "twitter",
    name: "Twitter / X",
    icon: Twitter,
    color: "text-sky-400",
    gradient: "from-sky-500 to-blue-600",
    description: "Download videos & GIFs from Twitter/X posts",
    placeholder: "https://x.com/user/status/...",
    supportedFormats: ["HD Video", "SD Video", "GIF"],
  },
  {
    id: "facebook",
    name: "Facebook",
    icon: Facebook,
    color: "text-blue-500",
    gradient: "from-blue-600 to-blue-400",
    description: "Download videos & reels from Facebook",
    placeholder: "https://facebook.com/watch?v=...",
    supportedFormats: ["HD Video", "SD Video"],
  },
  {
    id: "pinterest",
    name: "Pinterest",
    icon: Image,
    color: "text-red-400",
    gradient: "from-red-500 to-pink-400",
    description: "Download pins, videos & images from Pinterest in HD",
    placeholder: "https://pinterest.com/pin/...",
    supportedFormats: ["HD Image", "HD Video", "Original"],
  },
  {
    id: "reddit",
    name: "Reddit",
    icon: Film,
    color: "text-orange-500",
    gradient: "from-orange-500 to-red-500",
    description: "Download videos & GIFs from Reddit posts",
    placeholder: "https://reddit.com/r/sub/comments/...",
    supportedFormats: ["HD Video", "SD Video", "Audio"],
  },
  {
    id: "vimeo",
    name: "Vimeo",
    icon: Video,
    color: "text-cyan-400",
    gradient: "from-cyan-500 to-blue-500",
    description: "Download high-quality videos from Vimeo",
    placeholder: "https://vimeo.com/...",
    supportedFormats: ["1080p", "720p", "480p"],
  },
];

export const getPlatform = (id: string) => platforms.find((p) => p.id === id);

export const detectPlatform = (url: string): string | null => {
  if (url.includes("youtube.com") || url.includes("youtu.be")) return "youtube";
  if (url.includes("tiktok.com")) return "tiktok";
  if (url.includes("instagram.com")) return "instagram";
  if (url.includes("twitter.com") || url.includes("x.com")) return "twitter";
  if (url.includes("facebook.com") || url.includes("fb.watch")) return "facebook";
  if (url.includes("pinterest.com") || url.includes("pin.it")) return "pinterest";
  if (url.includes("reddit.com") || url.includes("redd.it")) return "reddit";
  if (url.includes("vimeo.com")) return "vimeo";
  return null;
};
