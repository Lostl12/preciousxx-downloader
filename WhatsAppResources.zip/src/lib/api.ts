export interface DownloadResult {
  thumbnail: string;
  title?: string;
  qualities: { label: string; url: string }[];
  error?: string;
}

const API_BASE = import.meta.env.VITE_API_URL || "";

// ---- Universal downloader API (primary free API) ----
const UNIVERSAL_API = "https://universaldownloaderapi.vercel.app";

// ---- GiftedTech API (secondary fallback) ----
const GIFTED_API = "https://api.giftedtech.co.ke";
const GIFTED_KEY = import.meta.env.VITE_GIFTED_API_KEY || "gifted";

// ---- fdown API (Facebook-specific fallback) ----
const FDOWN_API = "https://fdown.isuru.eu.org";

function sanitizeMessage(message: string): string {
  return message
    .replace(/gifted\s*tech|giftedtech|gifted/gi, "server")
    .replace(/tikwm/gi, "server")
    .replace(/fdown|isuru/gi, "server")
    .replace(/eliteprotech/gi, "server")
    .replace(/siputzx/gi, "server")
    .replace(/request failed with status code \d+/gi, "This quality is unavailable right now");
}

function sanitizePayload<T>(payload: T): T {
  if (!payload || typeof payload !== "object") return payload;
  const data = payload as Record<string, unknown>;
  delete data.creator;
  if (typeof data.message === "string") {
    data.message = sanitizeMessage(data.message);
  }
  if (data.result && typeof data.result === "object") {
    delete (data.result as Record<string, unknown>).creator;
  }
  return payload;
}

function isProviderApiUrl(url: string): boolean {
  return (
    url.startsWith(`${GIFTED_API}/api/download/`) ||
    url.startsWith(`${UNIVERSAL_API}/`) ||
    url.startsWith(`${FDOWN_API}/`)
  );
}

function pushQuality(
  qualities: { label: string; url: string }[],
  quality: { label: string; url?: string | null },
): void {
  const url = quality.url?.trim();
  if (!url || isProviderApiUrl(url)) return;
  if (qualities.some((item) => item.url === url)) return;
  qualities.push({ label: quality.label, url });
}

// ============ URL CLEANING ============

function cleanUrl(url: string): string {
  try {
    const u = new URL(url);
    u.searchParams.delete("si");
    u.searchParams.delete("feature");
    u.searchParams.delete("utm_source");
    u.searchParams.delete("utm_medium");
    u.searchParams.delete("utm_campaign");
    return u.toString();
  } catch {
    return url;
  }
}

function normalizeYouTubeUrl(url: string): string {
  const id = extractYTId(url);
  if (!id) return cleanUrl(url);
  return `https://www.youtube.com/watch?v=${id}`;
}

function extractYTId(url: string): string {
  const patterns = [
    /(?:youtube\.com\/watch\?.*v=)([a-zA-Z0-9_-]{11})/,
    /(?:youtu\.be\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/shorts\/)([a-zA-Z0-9_-]{11})/,
    /(?:youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return "";
}

// ============ PLATFORM DETECTION ============

function detectPlatform(url: string): string {
  if (url.includes("youtube.com") || url.includes("youtu.be")) return "youtube";
  if (url.includes("tiktok.com")) return "tiktok";
  if (url.includes("instagram.com")) return "instagram";
  if (url.includes("twitter.com") || url.includes("x.com")) return "twitter";
  if (url.includes("facebook.com") || url.includes("fb.watch")) return "facebook";
  if (url.includes("pinterest.com") || url.includes("pin.it")) return "pinterest";
  if (url.includes("reddit.com") || url.includes("redd.it")) return "reddit";
  if (url.includes("vimeo.com")) return "vimeo";
  return "generic";
}

// ============ PRIMARY: Custom backend ============

async function fetchFromPrimary(url: string): Promise<DownloadResult> {
  if (!API_BASE) throw new Error("No primary API configured");
  const res = await fetch(`${API_BASE}/preview?url=${encodeURIComponent(url)}`);
  const data = await res.json();
  if (data.error) throw new Error(data.error);
  return data;
}

// ============ EDGE FUNCTION PROXY (server-side multi-provider with api.js APIs) ============

async function fetchFromEdgeFunction(rawUrl: string): Promise<DownloadResult> {
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  if (!supabaseUrl) throw new Error("No Supabase URL configured");

  const res = await fetch(
    `${supabaseUrl}/functions/v1/social-download`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ url: rawUrl }),
    }
  );

  const data = await res.json();
  if (!res.ok || data.error) throw new Error(data?.error || "Edge function failed");
  if (!data.qualities || data.qualities.length === 0) throw new Error("No download links from edge function");
  return data;
}

// ============ UNIVERSAL DOWNLOADER API ============

function getUniversalEndpoint(platform: string): string {
  const map: Record<string, string> = {
    youtube: "youtube",
    tiktok: "tiktok",
    instagram: "meta",
    facebook: "meta",
    twitter: "twitter",
    pinterest: "pinterest",
    reddit: "reddit",
    vimeo: "vimeo",
  };
  return map[platform] || "meta";
}

async function fetchFromUniversalAPI(rawUrl: string): Promise<DownloadResult> {
  const platform = detectPlatform(rawUrl);
  const endpoint = getUniversalEndpoint(platform);
  const url = platform === "youtube" ? normalizeYouTubeUrl(rawUrl) : cleanUrl(rawUrl);

  const res = await fetch(`${UNIVERSAL_API}/api/${endpoint}/download?url=${encodeURIComponent(url)}`);
  if (!res.ok) throw new Error(`Universal API returned ${res.status}`);

  const data = await res.json();
  if (!data || data.error) throw new Error(data?.error || "Universal API failed");

  const qualities: { label: string; url: string }[] = [];
  let thumbnail = "";
  let title = "";

  if (data.data) {
    const d = data.data;
    thumbnail = d.thumbnail || d.cover || d.image || "";
    title = d.title || d.caption || "";

    if (Array.isArray(d.downloads)) {
      d.downloads.forEach((item: { url?: string; quality?: string; type?: string; label?: string }, i: number) => {
        pushQuality(qualities, {
          label: item.label || item.quality || item.type || `Download ${i + 1}`,
          url: item.url,
        });
      });
    }

    if (d.download_url) pushQuality(qualities, { label: "Download", url: d.download_url });
    if (d.hd) pushQuality(qualities, { label: "HD Video", url: d.hd });
    if (d.sd) pushQuality(qualities, { label: "SD Video", url: d.sd });
    if (d.video) pushQuality(qualities, { label: "Video", url: d.video });
    if (d.audio) pushQuality(qualities, { label: "Audio", url: d.audio });
    if (d.music) pushQuality(qualities, { label: "Audio MP3", url: d.music });
    if (d.url && typeof d.url === "string") pushQuality(qualities, { label: "Download", url: d.url });

    if (Array.isArray(d.media)) {
      d.media.forEach((item: { url?: string; quality?: string; type?: string }, i: number) => {
        pushQuality(qualities, {
          label: item.quality || item.type || `Media ${i + 1}`,
          url: item.url,
        });
      });
    }
  }

  if (data.url) pushQuality(qualities, { label: "Download", url: data.url });
  if (data.download_url) pushQuality(qualities, { label: "Download", url: data.download_url });

  if (qualities.length === 0) throw new Error("No download links from Universal API");

  if (!thumbnail && platform === "youtube") {
    const ytId = extractYTId(rawUrl);
    if (ytId) thumbnail = `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`;
  }

  return { thumbnail, title, qualities };
}

// ============ TIKTOK via tikwm ============

async function fetchTikTokDirect(url: string): Promise<DownloadResult> {
  const res = await fetch(`https://tikwm.com/api/?url=${encodeURIComponent(url)}`);
  const data = await res.json();
  if (!data.data) throw new Error("TikTok fetch failed");
  return {
    thumbnail: data.data.cover || "",
    title: data.data.title || "TikTok Video",
    qualities: [
      { label: "HD Video (No Watermark)", url: data.data.play },
      ...(data.data.wmplay ? [{ label: "Watermark Video", url: data.data.wmplay }] : []),
      ...(data.data.music ? [{ label: "Audio MP3", url: data.data.music }] : []),
    ],
  };
}

// ============ FACEBOOK via fdown (yt-dlp based) ============

async function fetchFacebookDirect(rawUrl: string): Promise<DownloadResult> {
  const url = cleanUrl(rawUrl);
  const res = await fetch(`${FDOWN_API}/info`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ url, quality: "best" }),
  });

  if (!res.ok) {
    const errData = await res.json().catch(() => ({}));
    throw new Error(
      sanitizeMessage(
        (errData as { detail?: { message?: string } })?.detail?.message || `Facebook API returned ${res.status}`
      )
    );
  }

  const data = await res.json();

  if (data.status !== "success") {
    throw new Error(sanitizeMessage(data?.detail?.message || "Facebook download failed"));
  }

  const qualities: { label: string; url: string }[] = [];
  let thumbnail = "";
  let title = "";

  if (data.video_info) {
    thumbnail = data.video_info.thumbnail || "";
    title = data.video_info.title || data.video_info.uploader || "Facebook Video";
  }

  if (Array.isArray(data.available_formats)) {
    const sorted = [...data.available_formats].sort((a: { quality?: string }, b: { quality?: string }) => {
      const qa = parseInt(a.quality || "0");
      const qb = parseInt(b.quality || "0");
      return qb - qa;
    });

    const top = sorted.slice(0, 4);
    top.forEach((fmt: { quality?: string; url?: string; ext?: string }) => {
      if (fmt.url) {
        pushQuality(qualities, {
          label: `${fmt.ext?.toUpperCase() || "MP4"} ${fmt.quality || ""}p`,
          url: fmt.url,
        });
      }
    });
  }

  if (data.download_url) {
    pushQuality(qualities, { label: "Download", url: data.download_url });
  }

  if (qualities.length === 0) throw new Error("No download links from Facebook API");

  return { thumbnail, title, qualities };
}

// ============ GIFTED TECH API (hidden, acts as internal engine) ============

async function internalApiFetch(endpoint: string, params: Record<string, string>) {
  const query = new URLSearchParams({ apikey: GIFTED_KEY, ...params }).toString();
  const res = await fetch(`${GIFTED_API}/api/download/${endpoint}?${query}`);
  const data = sanitizePayload(await res.json());

  if (!res.ok || data.success === false) {
    throw new Error(
      sanitizeMessage(typeof data.message === "string" ? data.message : "Could not fetch media"),
    );
  }
  return data;
}

async function fetchFromGiftedAPI(rawUrl: string): Promise<DownloadResult> {
  const platform = detectPlatform(rawUrl);
  const url = platform === "youtube" ? normalizeYouTubeUrl(rawUrl) : cleanUrl(rawUrl);
  const qualities: { label: string; url: string }[] = [];
  let thumbnail = "";
  let title = "";

  if (platform === "youtube") {
    const ytId = extractYTId(rawUrl);
    thumbnail = `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`;

    const mainData = await internalApiFetch("ytmp4", { url });
    if (mainData.success && mainData.result) {
      title = mainData.result.title || "";
      if (mainData.result.thumbnail) thumbnail = mainData.result.thumbnail;
      if (mainData.result.download_url) {
        pushQuality(qualities, {
          label: `MP4 ${mainData.result.quality || "HD"}`,
          url: mainData.result.download_url,
        });
      }
    }

    const [fallbackVideo, audioData] = await Promise.allSettled([
      internalApiFetch("dlmp4", { url, quality: "480" }),
      internalApiFetch("ytaudio", { url }),
    ]);

    if (fallbackVideo.status === "fulfilled" && fallbackVideo.value.result) {
      const result = fallbackVideo.value.result;
      if (!thumbnail && result.thumbnail) thumbnail = result.thumbnail;
      pushQuality(qualities, { label: `MP4 ${result.quality || "480p"}`, url: result.download_url });
    }
    if (audioData.status === "fulfilled" && audioData.value.result) {
      const result = audioData.value.result;
      if (!thumbnail && result.thumbnail) thumbnail = result.thumbnail;
      pushQuality(qualities, { label: `MP3 ${result.quality || "128kbps"}`, url: result.download_url });
    }
  } else if (platform === "tiktok") {
    return await fetchTikTokDirect(rawUrl);
  } else if (platform === "twitter") {
    const data = await internalApiFetch("twitter", { url });
    if (data.success && data.result) {
      if (Array.isArray(data.result)) {
        data.result.forEach((item: { url?: string; quality?: string }, i: number) => {
          pushQuality(qualities, { label: item.quality || `Quality ${i + 1}`, url: item.url });
        });
      } else if (data.result.download_url) {
        pushQuality(qualities, { label: "HD Video", url: data.result.download_url });
      }
      thumbnail = data.result.thumbnail || "";
    }
  } else if (platform === "instagram") {
    const data = await internalApiFetch("instagram", { url });
    if (data.success && data.result) {
      if (Array.isArray(data.result)) {
        data.result.forEach((item: { url?: string; type?: string }, i: number) => {
          pushQuality(qualities, { label: item.type || `Download ${i + 1}`, url: item.url });
        });
      } else if (data.result.download_url) {
        pushQuality(qualities, { label: "HD", url: data.result.download_url });
      }
      thumbnail = data.result.thumbnail || "";
    }
  } else if (platform === "facebook") {
    const data = await internalApiFetch("facebook", { url });
    if (data.success && data.result) {
      if (data.result.hd) pushQuality(qualities, { label: "HD", url: data.result.hd });
      if (data.result.sd) pushQuality(qualities, { label: "SD", url: data.result.sd });
      if (data.result.download_url) pushQuality(qualities, { label: "Download", url: data.result.download_url });
      thumbnail = data.result.thumbnail || "";
    }
  } else if (platform === "pinterest") {
    const data = await internalApiFetch("pinterest", { url });
    if (data.success && data.result) {
      if (data.result.download_url) pushQuality(qualities, { label: "HD Download", url: data.result.download_url });
      if (data.result.url) pushQuality(qualities, { label: "Download", url: data.result.url });
      thumbnail = data.result.thumbnail || "";
    }
  } else if (platform === "reddit") {
    const data = await internalApiFetch("reddit", { url });
    if (data.success && data.result) {
      if (data.result.hd) pushQuality(qualities, { label: "HD Video", url: data.result.hd });
      if (data.result.sd) pushQuality(qualities, { label: "SD Video", url: data.result.sd });
      if (data.result.download_url) pushQuality(qualities, { label: "HD Video", url: data.result.download_url });
      if (Array.isArray(data.result)) {
        data.result.forEach((item: { url?: string; quality?: string }, i: number) => {
          pushQuality(qualities, { label: item.quality || `Quality ${i + 1}`, url: item.url });
        });
      }
      if (data.result.audio) pushQuality(qualities, { label: "Audio", url: data.result.audio });
      thumbnail = data.result.thumbnail || data.result.cover || "";
      title = data.result.title || "";
    }
  } else if (platform === "vimeo") {
    const data = await internalApiFetch("vimeo", { url });
    if (data.success && data.result) {
      if (data.result.download_url) pushQuality(qualities, { label: `MP4 ${data.result.quality || "HD"}`, url: data.result.download_url });
      if (data.result.hd) pushQuality(qualities, { label: "1080p", url: data.result.hd });
      if (data.result.sd) pushQuality(qualities, { label: "720p", url: data.result.sd });
      thumbnail = data.result.thumbnail || "";
      title = data.result.title || "";
    }
  } else {
    throw new Error("Platform not supported yet");
  }

  if (qualities.length === 0) throw new Error("No download links found");
  return { thumbnail, title, qualities };
}

// ============ DIRECT META SCRAPING via CORS proxy ============

const CORS_PROXIES = [
  (u: string) => `https://api.allorigins.win/raw?url=${encodeURIComponent(u)}`,
  (u: string) => `https://api.codetabs.com/v1/proxy?quest=${encodeURIComponent(u)}`,
];

function extractMeta(html: string, property: string): string {
  const re1 = new RegExp(`<meta[^>]+(?:property|name)="${property}"[^>]+content="([^"]+)"`, "i");
  const re2 = new RegExp(`<meta[^>]+content="([^"]+)"[^>]+(?:property|name)="${property}"`, "i");
  return (html.match(re1)?.[1] || html.match(re2)?.[1] || "").trim();
}

async function fetchViaMetaScraping(rawUrl: string): Promise<DownloadResult> {
  const platform = detectPlatform(rawUrl);

  for (const makeProxy of CORS_PROXIES) {
    try {
      const res = await fetch(makeProxy(rawUrl), { signal: AbortSignal.timeout(8000) });
      if (!res.ok) continue;
      const html = await res.text();
      if (!html || html.length < 200) continue;

      const ogImage = extractMeta(html, "og:image");
      const ogVideo = extractMeta(html, "og:video") || extractMeta(html, "og:video:url") || extractMeta(html, "og:video:secure_url");
      const ogTitle = extractMeta(html, "og:title") || extractMeta(html, "title");
      const twitterImage = extractMeta(html, "twitter:image");
      const twitterPlayer = extractMeta(html, "twitter:player:stream");

      const qualities: { label: string; url: string }[] = [];

      if (platform === "pinterest") {
        const imageUrl = ogImage || twitterImage;
        if (imageUrl) {
          const originalUrl = imageUrl.replace(/\/\d+x\d*\//, "/originals/");
          pushQuality(qualities, { label: "HD Original Image", url: originalUrl });
          if (originalUrl !== imageUrl) {
            pushQuality(qualities, { label: "Standard Image", url: imageUrl });
          }
          const medUrl = imageUrl.replace(/\/\d+x\d*\//, "/736x/");
          if (medUrl !== originalUrl && medUrl !== imageUrl) {
            pushQuality(qualities, { label: "Medium Image", url: medUrl });
          }
          // Check for video pins
          const videoMatch = html.match(/"video_list":\s*\{[^}]*"V_720P":\s*\{[^}]*"url":\s*"([^"]+)"/);
          const videoMatch2 = html.match(/"url":\s*"(https:\/\/v1?\.pinimg\.com\/videos\/[^"]+)"/);
          const videoUrl = videoMatch?.[1] || videoMatch2?.[1];
          if (videoUrl) {
            pushQuality(qualities, { label: "HD Video", url: videoUrl.replace(/\\u002F/g, "/") });
          }
        }
      }

      if (ogVideo && !ogVideo.includes("embed")) {
        pushQuality(qualities, { label: "Video", url: ogVideo });
      }
      if (twitterPlayer) {
        pushQuality(qualities, { label: "Video Stream", url: twitterPlayer });
      }
      if (ogImage && qualities.length === 0) {
        pushQuality(qualities, { label: "Image", url: ogImage });
      }

      if (qualities.length > 0) {
        return {
          thumbnail: ogImage || twitterImage || "",
          title: ogTitle || `${platform} Media`,
          qualities,
        };
      }
    } catch {
      continue;
    }
  }
  throw new Error("Meta scraping failed");
}

// ============ COBALT API (free, open-source multi-platform) ============

async function fetchFromCobalt(rawUrl: string): Promise<DownloadResult> {
  const res = await fetch("https://api.cobalt.tools/", {
    method: "POST",
    headers: {
      "Accept": "application/json",
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ url: rawUrl }),
  });
  if (!res.ok) throw new Error(`Cobalt ${res.status}`);
  const data = await res.json();

  const qualities: { label: string; url: string }[] = [];

  if (data.status === "redirect" && data.url) {
    pushQuality(qualities, { label: "Download", url: data.url });
  } else if (data.status === "picker" && Array.isArray(data.picker)) {
    data.picker.forEach((item: { url?: string; type?: string }, i: number) => {
      if (item.url) pushQuality(qualities, { label: item.type || `Download ${i + 1}`, url: item.url });
    });
  } else if (data.status === "stream" && data.url) {
    pushQuality(qualities, { label: "Stream Download", url: data.url });
  }

  if (qualities.length === 0) throw new Error("No links from Cobalt");

  return {
    thumbnail: "",
    title: "",
    qualities,
  };
}

// ============ DavidXTech API (client-side fallback) ============

const DAVIDX_API = "https://api.davidxtech.de";
const DAVIDX_KEY = "FREE-TEST-KEY-3000";

async function fetchFromDavidXTech(rawUrl: string): Promise<DownloadResult> {
  const res = await fetch(`${DAVIDX_API}/info`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "X-API-Key": DAVIDX_KEY },
    body: JSON.stringify({ url: rawUrl }),
  });
  if (!res.ok) throw new Error(`DavidXTech ${res.status}`);
  const data = await res.json();
  const qualities: { label: string; url: string }[] = [];
  let thumbnail = "";
  let title = "";
  const d = data.result || data.data;
  if (d) {
    thumbnail = d.thumbnail || d.cover || d.image || "";
    title = d.title || d.caption || "";
    if (Array.isArray(d.formats)) d.formats.forEach((f: { url?: string; quality?: string }) => { if (f.url) pushQuality(qualities, { label: f.quality || "Download", url: f.url }); });
    if (Array.isArray(d.downloads)) d.downloads.forEach((f: { url?: string; quality?: string; label?: string }) => { if (f.url) pushQuality(qualities, { label: f.quality || f.label || "Download", url: f.url }); });
    if (d.download_url) pushQuality(qualities, { label: "Download", url: d.download_url });
    if (d.hd) pushQuality(qualities, { label: "HD Video", url: d.hd });
    if (d.sd) pushQuality(qualities, { label: "SD Video", url: d.sd });
    if (d.video) pushQuality(qualities, { label: "Video", url: d.video });
    if (d.audio) pushQuality(qualities, { label: "Audio", url: d.audio });
    if (d.url && typeof d.url === "string") pushQuality(qualities, { label: "Download", url: d.url });
  }
  if (qualities.length === 0) throw new Error("No links from DavidXTech");
  return { thumbnail, title, qualities };
}

// ============ INSTAGRAM via siputzx (from api.js) ============

async function fetchInstagramDirect(rawUrl: string): Promise<DownloadResult> {
  const res = await fetch(`https://api.siputzx.my.id/api/d/igdl?url=${encodeURIComponent(rawUrl)}`);
  if (!res.ok) throw new Error(`Instagram API ${res.status}`);
  const data = await res.json();
  const qualities: { label: string; url: string }[] = [];
  let thumbnail = "";

  if (data.data && Array.isArray(data.data)) {
    data.data.forEach((item: { url?: string; type?: string; thumbnail?: string }, i: number) => {
      if (item.url) pushQuality(qualities, { label: item.type || `Download ${i + 1}`, url: item.url });
      if (item.thumbnail && !thumbnail) thumbnail = item.thumbnail;
    });
  } else if (data.result) {
    const r = data.result;
    if (r.url) pushQuality(qualities, { label: "Download", url: r.url });
    if (r.download_url) pushQuality(qualities, { label: "Download", url: r.download_url });
    thumbnail = r.thumbnail || "";
  }

  if (qualities.length === 0) throw new Error("No Instagram download links");
  return { thumbnail, title: "Instagram Media", qualities };
}

// ============ MAIN FETCH WITH AUTO-FALLBACK (multi-layer) ============

export async function fetchMedia(rawUrl: string): Promise<DownloadResult> {
  const errors: string[] = [];
  const platform = detectPlatform(rawUrl);

  // Layer 1: Custom backend proxy (if configured)
  if (API_BASE) {
    try {
      return await fetchFromPrimary(rawUrl);
    } catch (e) {
      errors.push(`Primary: ${e instanceof Error ? e.message : "failed"}`);
      console.warn("Primary API failed, trying next...");
    }
  }

  // Layer 2: Platform-specific direct APIs (most reliable)
  if (platform === "tiktok") {
    try {
      return await fetchTikTokDirect(rawUrl);
    } catch (e) {
      errors.push(`TikTok direct: ${e instanceof Error ? e.message : "failed"}`);
      console.warn("TikTok direct failed...");
    }
  }

  if (platform === "facebook") {
    try {
      return await fetchFacebookDirect(rawUrl);
    } catch (e) {
      errors.push(`Facebook direct: ${e instanceof Error ? e.message : "failed"}`);
      console.warn("Facebook direct API failed, trying fallbacks...");
    }
  }

  if (platform === "instagram") {
    try {
      return await fetchInstagramDirect(rawUrl);
    } catch (e) {
      errors.push(`Instagram direct: ${e instanceof Error ? e.message : "failed"}`);
      console.warn("Instagram direct failed...");
    }
  }

  // Layer 3: Pinterest & generic — meta scraping first (best for Pinterest HD images)
  if (platform === "pinterest" || platform === "generic") {
    try {
      return await fetchViaMetaScraping(rawUrl);
    } catch (e) {
      errors.push(`Meta scraping: ${e instanceof Error ? e.message : "failed"}`);
      console.warn("Meta scraping failed, trying APIs...");
    }
  }

  // Layer 4: Edge Function (server-side — handles Pinterest HD, YouTube via EliteProTech, etc.)
  try {
    return await fetchFromEdgeFunction(rawUrl);
  } catch (e) {
    errors.push(`Edge function: ${e instanceof Error ? e.message : "failed"}`);
    console.warn("Edge function failed, trying client-side fallbacks...");
  }

  // Layer 5: Cobalt API (free, open-source)
  try {
    return await fetchFromCobalt(rawUrl);
  } catch (e) {
    errors.push(`Cobalt: ${e instanceof Error ? e.message : "failed"}`);
    console.warn("Cobalt API failed, trying next...");
  }

  // Layer 6: DavidXTech API
  try {
    return await fetchFromDavidXTech(rawUrl);
  } catch (e) {
    errors.push(`DavidXTech: ${e instanceof Error ? e.message : "failed"}`);
    console.warn("DavidXTech API failed, trying fallbacks...");
  }

  // Layer 7: Universal Downloader API
  try {
    return await fetchFromUniversalAPI(rawUrl);
  } catch (e) {
    errors.push(`Universal: ${e instanceof Error ? e.message : "failed"}`);
    console.warn("Universal API failed, trying fallback APIs...");
  }

  // Layer 8: GiftedTech API (last resort)
  try {
    return await fetchFromGiftedAPI(rawUrl);
  } catch (e) {
    errors.push(`Fallback: ${e instanceof Error ? e.message : "failed"}`);
  }

  // Layer 9: Meta scraping as ultimate fallback for all platforms
  if (platform !== "pinterest" && platform !== "generic") {
    try {
      return await fetchViaMetaScraping(rawUrl);
    } catch (e) {
      errors.push(`Meta fallback: ${e instanceof Error ? e.message : "failed"}`);
    }
  }

  console.error("All APIs failed:", errors);
  throw new Error("Could not fetch media. Please check the URL and try again.");
}

export function getDownloadUrl(fileUrl: string): string {
  if (isProviderApiUrl(fileUrl)) return "";
  if (fileUrl.startsWith("http")) return fileUrl;
  return `${API_BASE}/download?url=${encodeURIComponent(fileUrl)}`;
}
