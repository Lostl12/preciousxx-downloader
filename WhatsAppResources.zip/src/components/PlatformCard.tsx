import { Link } from "react-router-dom";
import type { Platform } from "@/lib/platforms";

interface PlatformCardProps {
  platform: Platform;
}

const PlatformCard = ({ platform }: PlatformCardProps) => {
  const Icon = platform.icon;

  return (
    <Link
      to={`/downloader/${platform.id}`}
      className="group relative overflow-hidden rounded-xl border border-border bg-card p-6 transition-all duration-300 hover:border-neon-pink/50 hover:glow-pink"
    >
      <div
        className="absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity"
        style={{ backgroundImage: `linear-gradient(135deg, hsl(var(--neon-pink)), hsl(var(--neon-cyan)))` }}
      />
      <div className="relative z-10">
        <div className={`mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-gradient-to-br ${platform.gradient}`}>
          <Icon className="h-6 w-6 text-primary-foreground" />
        </div>
        <h3 className="mb-2 text-lg font-heading font-semibold text-foreground">
          {platform.name}
        </h3>
        <p className="text-sm text-muted-foreground leading-relaxed">
          {platform.description}
        </p>
        <div className="mt-4 flex flex-wrap gap-1.5">
          {platform.supportedFormats.slice(0, 3).map((fmt) => (
            <span key={fmt} className="rounded-full border border-border bg-muted px-2.5 py-0.5 text-xs text-muted-foreground">
              {fmt}
            </span>
          ))}
        </div>
      </div>
    </Link>
  );
};

export default PlatformCard;
