import { useState } from "react";
import { Link } from "react-router-dom";
import { Download, Menu, MessageCircle, X } from "lucide-react";
import { buttonVariants } from "@/components/ui/button";

const ownerWhatsappUrl = "https://wa.me/2349068551055";

const Navbar = () => {
  const [open, setOpen] = useState(false);

  const links = [
    { to: "/", label: "Home" },
    { to: "/downloader", label: "Universal" },
    { to: "/downloader/youtube", label: "YouTube" },
    { to: "/downloader/tiktok", label: "TikTok" },
    { to: "/downloader/instagram", label: "Instagram" },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="container mx-auto flex h-14 items-center justify-between px-4">
        <Link to="/" className="flex items-center gap-2" onClick={() => setOpen(false)}>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-primary">
            <Download className="h-4 w-4 text-primary-foreground" />
          </div>
          <span className="text-base font-heading font-bold text-gradient-primary">
            𝑷𝑹𝑬𝑪𝑰𝑶𝑼𝑺 x
          </span>
        </Link>

        <div className="hidden md:flex items-center gap-4">
          {links.map((l) => (
            <Link key={l.to} to={l.to} className="text-sm text-muted-foreground hover:text-foreground transition-colors">
              {l.label}
            </Link>
          ))}
          <a
            href={ownerWhatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat with the owner on WhatsApp"
            className={buttonVariants({ variant: "neonOutline", size: "sm" })}
          >
            <MessageCircle className="h-4 w-4" />
            Owner WhatsApp
          </a>
        </div>

        <button onClick={() => setOpen(!open)} className="md:hidden p-2 text-muted-foreground hover:text-foreground">
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="md:hidden border-t border-border bg-background/95 backdrop-blur-xl">
          <div className="container mx-auto px-4 py-3 flex flex-col gap-1">
            {links.map((l) => (
              <Link
                key={l.to}
                to={l.to}
                onClick={() => setOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground hover:bg-muted transition-colors"
              >
                {l.label}
              </Link>
            ))}
            <a
              href={ownerWhatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-2 inline-flex items-center justify-center gap-2 rounded-lg border border-border bg-card px-3 py-2.5 text-sm text-foreground transition-colors hover:bg-muted"
            >
              <MessageCircle className="h-4 w-4" />
              Owner WhatsApp
            </a>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
