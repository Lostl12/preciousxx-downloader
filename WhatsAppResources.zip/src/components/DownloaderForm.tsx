import { useState } from "react";
import { Download, Loader2, Clipboard, X, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { fetchMedia, getDownloadUrl, type DownloadResult } from "@/lib/api";

interface DownloaderFormProps {
  placeholder?: string;
  platformName?: string;
}

async function triggerDownload(fileUrl: string, filename: string) {
  try {
    const res = await fetch(fileUrl, { mode: "cors" });
    if (!res.ok) throw new Error("fetch failed");
    const blob = await res.blob();
    const blobUrl = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = blobUrl;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(blobUrl);
      document.body.removeChild(a);
    }, 100);
  } catch {
    window.open(fileUrl, "_blank", "noopener,noreferrer");
  }
}

function guessFilename(url: string, label: string): string {
  try {
    const pathname = new URL(url).pathname;
    const ext = pathname.split(".").pop()?.split("?")[0] || "";
    const validExt = /^(mp4|mp3|jpg|jpeg|png|gif|webp|webm|mkv|mov|m4a|wav|ogg)$/i.test(ext);
    const safeName = label.replace(/[^a-zA-Z0-9 ]/g, "").trim().replace(/\s+/g, "_") || "download";
    return validExt ? `${safeName}.${ext}` : `${safeName}.mp4`;
  } catch {
    return "download.mp4";
  }
}

const DownloaderForm = ({ placeholder = "Paste any video link here...", platformName }: DownloaderFormProps) => {
  const [url, setUrl] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<DownloadResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [downloadingIndex, setDownloadingIndex] = useState<number | null>(null);

  const handleFetch = async () => {
    if (!url.trim()) return;
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const data = await fetchMedia(url.trim());
      setResult(data);
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Failed to fetch media";
      setError(msg.replace(/gifted(tech)?/gi, "server").replace(/tikwm/gi, "server"));
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (fileUrl: string, label: string, index: number) => {
    const resolvedUrl = getDownloadUrl(fileUrl);
    if (!resolvedUrl) return;
    setDownloadingIndex(index);
    try {
      await triggerDownload(resolvedUrl, guessFilename(resolvedUrl, label));
    } finally {
      setDownloadingIndex(null);
    }
  };

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      setUrl(text);
    } catch {
      // clipboard not available
    }
  };

  const handleClear = () => {
    setUrl("");
    setResult(null);
    setError(null);
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <div className="relative flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
        <div className="relative flex-1">
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && handleFetch()}
            placeholder={placeholder}
            className="w-full rounded-xl border border-border bg-muted px-4 py-3.5 pr-20 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all"
          />
          <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
            <button onClick={handlePaste} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground transition-colors" title="Paste">
              <Clipboard className="h-4 w-4" />
            </button>
            {url && (
              <button onClick={handleClear} className="p-1.5 rounded-md text-muted-foreground hover:text-foreground transition-colors" title="Clear">
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
        <Button variant="neon" size="lg" onClick={handleFetch} disabled={loading || !url.trim()} className="w-full sm:w-auto">
          {loading ? <Loader2 className="h-5 w-5 animate-spin" /> : <Download className="h-5 w-5" />}
          {loading ? "Fetching..." : "Fetch"}
        </Button>
      </div>

      {error && (
        <div className="mt-4 flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 p-4 text-sm text-destructive">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      {result && (
        <div className="mt-6 rounded-xl border border-border bg-card p-4 sm:p-6">
          <div className="flex flex-col gap-4">
            {result.thumbnail && (
              <img
                src={result.thumbnail}
                alt="Preview"
                className="w-full h-40 sm:h-48 object-cover rounded-lg"
                loading="lazy"
              />
            )}
            <div className="space-y-3">
              <h3 className="font-heading font-semibold text-foreground text-sm sm:text-base line-clamp-2">
                {result.title || (platformName ? `${platformName} Media` : "Media Ready")}
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground">
                Choose your preferred quality — powered by 𝑷𝑹𝑬𝑪𝑰𝑶𝑼𝑺 x
              </p>
              <div className="flex flex-wrap gap-2">
                {result.qualities.map((q, i) => (
                  <Button
                    key={i}
                    variant="neonOutline"
                    size="sm"
                    className="text-xs"
                    disabled={downloadingIndex === i}
                    onClick={() => handleDownload(q.url, q.label, i)}
                  >
                    {downloadingIndex === i ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <Download className="h-3 w-3" />
                    )}
                    {q.label}
                  </Button>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DownloaderForm;
