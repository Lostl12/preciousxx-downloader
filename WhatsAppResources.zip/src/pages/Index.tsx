import { Link } from "react-router-dom";
import { ArrowRight, Download, Globe, MessageCircle, Shield, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import PlatformCard from "@/components/PlatformCard";
import { platforms } from "@/lib/platforms";
import heroBg from "@/assets/hero-bg.jpg";

const ownerWhatsappUrl = "https://wa.me/2349068551055";

const Index = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative flex min-h-[90vh] items-center justify-center overflow-hidden">
        <div className="absolute inset-0">
          <img src={heroBg} alt="" className="h-full w-full object-cover opacity-30" width={1920} height={1080} />
          <div className="absolute inset-0 bg-gradient-to-b from-background/60 via-background/80 to-background" />
        </div>
        <div className="relative z-10 container mx-auto px-4 text-center">
          <div className="inline-flex items-center gap-2 rounded-full border border-border bg-muted/50 px-4 py-1.5 text-sm text-muted-foreground mb-6">
            <Zap className="h-3.5 w-3.5 text-neon-cyan" />
            Universal Video Downloader
          </div>
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-heading font-bold leading-tight mb-6">
            <span className="text-foreground">Download </span>
            <span className="text-gradient-primary">Anything</span>
            <br />
            <span className="text-foreground">From </span>
            <span className="text-gradient-secondary">Anywhere</span>
          </h1>
          <p className="mx-auto max-w-xl text-lg text-muted-foreground mb-8">
            YouTube, TikTok, Instagram, Twitter, Pinterest & more.
            Multiple qualities. Zero watermarks. Made by{" "}
            <span className="text-gradient-primary font-semibold">𝑷𝑹𝑬𝑪𝑰𝑶𝑼𝑺 x</span>
          </p>
          <div className="flex flex-wrap items-center justify-center gap-4">
            <Button asChild variant="neon" size="lg" className="text-base px-8">
              <Link to="/downloader">
                <Download className="h-5 w-5" />
                Start Downloading
              </Link>
            </Button>
            <Button asChild variant="neonCyan" size="lg" className="text-base px-8">
              <a href={ownerWhatsappUrl} target="_blank" rel="noopener noreferrer">
                <MessageCircle className="h-5 w-5" />
                Chat Owner
              </a>
            </Button>
            <Button asChild variant="neonOutline" size="lg" className="text-base px-8">
              <a href="#platforms">
                View Platforms
                <ArrowRight className="h-5 w-5" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              { icon: Zap, title: "Lightning Fast", desc: "Instant media fetching with multi-API fallback" },
              { icon: Shield, title: "No Watermark", desc: "Clean downloads without branding" },
              { icon: Globe, title: "10+ Platforms", desc: "YouTube, TikTok, IG, Twitter & more" },
            ].map((feat) => (
              <div key={feat.title} className="text-center">
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-primary">
                  <feat.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <h3 className="font-heading font-semibold text-foreground mb-2">{feat.title}</h3>
                <p className="text-sm text-muted-foreground">{feat.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Platforms */}
      <section id="platforms" className="py-20 border-t border-border">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-heading font-bold text-foreground mb-4">
              Supported <span className="text-gradient-primary">Platforms</span>
            </h2>
            <p className="text-muted-foreground max-w-lg mx-auto">
              Choose a platform or use the universal downloader to auto-detect
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-5xl mx-auto">
            {platforms.map((p) => (
              <PlatformCard key={p.id} platform={p} />
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            Made with ♡ by <span className="text-gradient-primary font-semibold">𝑷𝑹𝑬𝑪𝑰𝑶𝑼𝑺 x</span>
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
