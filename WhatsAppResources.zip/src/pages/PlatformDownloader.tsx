import { useParams, Link, Navigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import DownloaderForm from "@/components/DownloaderForm";
import { getPlatform } from "@/lib/platforms";

const PlatformDownloader = () => {
  const { platformId } = useParams<{ platformId: string }>();
  const platform = platformId ? getPlatform(platformId) : null;

  if (!platform) return <Navigate to="/downloader" replace />;

  const Icon = platform.icon;

  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <Link to="/downloader" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8">
          <ArrowLeft className="h-4 w-4" />
          All Platforms
        </Link>

        <div className="text-center mb-12">
          <div className={`mx-auto mb-4 inline-flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br ${platform.gradient}`}>
            <Icon className="h-8 w-8 text-primary-foreground" />
          </div>
          <h1 className="text-3xl sm:text-5xl font-heading font-bold mb-4 text-foreground">
            {platform.name} <span className="text-gradient-primary">Downloader</span>
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            {platform.description}
          </p>
          <div className="mt-4 flex flex-wrap justify-center gap-2">
            {platform.supportedFormats.map((fmt) => (
              <span key={fmt} className="rounded-full border border-neon-pink/30 bg-neon-pink/5 px-3 py-1 text-xs text-neon-pink">
                {fmt}
              </span>
            ))}
          </div>
        </div>

        <DownloaderForm placeholder={platform.placeholder} platformName={platform.name} />

        <div className="mt-16 max-w-2xl mx-auto rounded-xl border border-border bg-card p-6">
          <h2 className="font-heading font-semibold text-foreground mb-3">How to use</h2>
          <ol className="space-y-2 text-sm text-muted-foreground">
            <li>1. Copy the {platform.name} link you want to download</li>
            <li>2. Paste it in the input above (or use the paste button)</li>
            <li>3. Click "Fetch" to get available qualities</li>
            <li>4. Choose your preferred quality and download</li>
          </ol>
        </div>
      </div>
    </div>
  );
};

export default PlatformDownloader;
