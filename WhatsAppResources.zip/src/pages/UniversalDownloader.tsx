import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import DownloaderForm from "@/components/DownloaderForm";
import { platforms } from "@/lib/platforms";

const UniversalDownloader = () => {
  return (
    <div className="min-h-screen pt-24 pb-16">
      <div className="container mx-auto px-4">
        <Link to="/" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors mb-8">
          <ArrowLeft className="h-4 w-4" />
          Back to Home
        </Link>

        <div className="text-center mb-12">
          <h1 className="text-3xl sm:text-5xl font-heading font-bold mb-4">
            <span className="text-gradient-primary">Universal</span> <span className="text-foreground">Downloader</span>
          </h1>
          <p className="text-muted-foreground max-w-lg mx-auto">
            Paste any link from YouTube, TikTok, Instagram, Twitter, Pinterest, Reddit, Vimeo & more. We auto-detect the platform.
          </p>
        </div>

        <DownloaderForm placeholder="Paste any video link here..." />

        <div className="mt-16 max-w-3xl mx-auto">
          <h2 className="text-xl font-heading font-semibold text-foreground mb-6 text-center">
            Or choose a platform
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {platforms.map((p) => {
              const Icon = p.icon;
              return (
                <Link
                  key={p.id}
                  to={`/downloader/${p.id}`}
                  className="flex items-center gap-3 rounded-lg border border-border bg-card p-3 transition-all hover:border-neon-pink/50"
                >
                  <div className={`flex h-8 w-8 items-center justify-center rounded-md bg-gradient-to-br ${p.gradient}`}>
                    <Icon className="h-4 w-4 text-primary-foreground" />
                  </div>
                  <span className="text-sm font-medium text-foreground">{p.name}</span>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UniversalDownloader;
